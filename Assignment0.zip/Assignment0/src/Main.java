public class Main {
    /*
     * Student name: Jade Lawson
     * Course and section: INEW-2338-21700
     * Assignment: 0
     * My program code satisfies the requirements of the assignment by
     * successfully running an output of 'Hello World' as noted in the assignment.
     */
    public static void main(String[] args) {
        System.out.print("Hello World");
    }
}